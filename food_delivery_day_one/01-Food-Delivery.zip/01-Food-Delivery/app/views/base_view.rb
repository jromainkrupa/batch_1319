class BaseView
  def display(elements)
    elements.each do |element|
      puts print_sentence(element)
    end
  end

  def ask_for(stuff)
    puts stuff + "?"
    print "> "
    gets.chomp
  end
end