require_relative "base_view"
class MealView < BaseView

  def print_sentence(meal)
    "#{meal.id} - #{meal.name} (#{meal.price}€)"
  end
end
