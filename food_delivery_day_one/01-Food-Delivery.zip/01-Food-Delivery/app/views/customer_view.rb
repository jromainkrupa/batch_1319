require_relative "base_view"
class CustomerView < BaseView
  def print_sentence(customer)
    "#{customer.id} - #{customer.name} (#{customer.address})"
  end
end
