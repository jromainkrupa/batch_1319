class Router
  def initialize(meal_controller, customer_controller)
    @meal_controller = meal_controller
    @customer_controller = customer_controller
    @running = true
  end

  def run
    while @running
      puts 'Welcome to the restaurant'
      puts ":::::::: 🎁 ::::::::"
      choice = display_actions
      print `clear`
      route(choice)
    end
  end

  private

  def route(choice)
    case choice
    when 1 then @meal_controller.list
    when 2 then @meal_controller.add
    when 3 then @customer_controller.list
    when 4 then @customer_controller.add
    when 5 then @meal_controller.destroy
    when 9 then @running = false
    else
      puts "t'es mauvais"
    end
  
  end

  def display_actions
    puts "1 - List meals"
    puts "2 - Add a meal"
    puts "3 - List customers"
    puts "4 - Add customer"
    puts "5 - destroy meal"
    puts "9 - Quit"
    print '> '
    gets.chomp.to_i
  end
end